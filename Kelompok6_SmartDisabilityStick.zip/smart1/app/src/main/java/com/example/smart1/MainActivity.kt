package com.example.smart1

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import id.co.telkom.iot.AntaresHTTPAPI
import id.co.telkom.iot.AntaresResponse
import kotlinx.android.synthetic.main.activity_status.*
import org.json.JSONException
import org.json.JSONObject


class MainActivity : AppCompatActivity(), AntaresHTTPAPI.OnResponseListener {
    private var btnRefresh: Button? = null
    private var btnOn: Button? = null
    private var btnOff: Button? = null
    private var txtData: TextView? = null
    private val TAG = "ANTARES-API"
    private var antaresAPIHTTP: AntaresHTTPAPI? = null
    private var dataDevice: String? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_status)

        // --- Inisialisasi UI yang digunakan di aplikasi --- //
        txtData = findViewById<View>(R.id.txtData) as TextView

        // --- Inisialisasi API Antares --- //
        //antaresAPIHTTP = AntaresHTTPAPI.getInstance();
        antaresAPIHTTP = AntaresHTTPAPI()
        antaresAPIHTTP.addListener(this)
        txtData!!.setOnClickListener {
            antaresAPIHTTP.getLatestDataofDevice(
                "8fe0cf53bf23dba6:07dc7b12f54bcc93",
                "smartplan",
                "sensor"
            )
        }
        txtData2!!.setOnClickListener {
            antaresAPIHTTP.storeDataofDevice(
                1,
                "8fe0cf53bf23dba6:07dc7b12f54bcc93",
                "smartplan",
                "sensor",
                "{\\\"status\\\":\\\"1\\\"}"
            )
        }

            )
        }
    }

    fun onResponse(antaresResponse: AntaresResponse) {
        // --- Cetak hasil yang didapat dari ANTARES ke System Log --- //
        //Log.d(TAG,antaresResponse.toString());
        Log.d(TAG, Integer.toString(antaresResponse.getRequestCode()))
        if (antaresResponse.getRequestCode() === 0) {
            try {
                val body = JSONObject(antaresResponse.getBody())
                dataDevice = body.getJSONObject("m2m:cin").getString("con")
                runOnUiThread { txtData!!.text = dataDevice }
                Log.d(TAG, dataDevice)
            } catch (e: JSONException) {
                e.printStackTrace()
            }
        }
    }
}